EDIT HUB Android project (MAMUN)

This is the Android wrapper project for the EDIT HUB HTML prototype.
It is not itself an APK. It includes a GitHub Actions workflow that builds a
debug APK automatically.

Build steps (can be done from a phone):
1. Create/sign in to a GitHub account.
2. Create a new repository named edit-hub and upload the CONTENTS of this ZIP.
3. Open the repository's Actions tab.
4. Select "Build EDIT HUB APK" and tap "Run workflow" (or wait for the first push build).
5. Open the completed workflow run, scroll to Artifacts, and download EDIT-HUB-APK.
6. Extract the artifact ZIP; install app-debug.apk on Android. Android may ask you
   to allow installation from that browser/file manager.

Important:
- This is a debug APK for testing, not a Play Store release.
- Files are stored locally inside the app/browser storage on that device.
- Online accounts, cloud backup, and friend-to-friend syncing are NOT included yet.
- Keep backup copies of important files.
